# main_game.py
import pygame
import sys
import random
import math
import os
import ctypes
from pygame import gfxdraw
from game_utils import set_input_method_to_english, GameData

# Initialize pygame
pygame.init()

# 初始化混音器
pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
# 增加同时播放的音效数量
pygame.mixer.set_num_channels(16)

def set_input_method_to_english():
    try:
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        hkl = user32.GetKeyboardLayout(0)
        if hkl != 0x0409:
            user32.LoadKeyboardLayoutW("00000409", 0x00000001)
    except:
        print("请手动调整输入法为英文输入法")

def resource_path(relative_path):
    """ 获取资源绝对路径，兼容开发环境和PyInstaller打包环境 """
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# 获取当前脚本所在目录
current_dir = os.path.dirname(os.path.abspath(__file__))

# 加载音效的函数
def load_sound(filename):
    try:
        path = os.path.join(current_dir, "music", filename)
        return pygame.mixer.Sound(path)
    except Exception as e:
        print(f"无法加载音效 {filename}: {str(e)}")
        # 创建空音效对象
        class DummySound:
            def play(self): pass
        return DummySound()

# Game window settings
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Python Shooter Game")

# Color definitions
BACKGROUND = (20, 20, 35)
PLAYER_COLOR = (0, 200, 255)
ENEMY_COLOR = (255, 80, 80)
PLAYER_BULLET_COLOR = (255, 215, 0)  # Gold
ENEMY_BULLET_COLOR = (255, 50, 50)   # Red
SHOTGUN_COLOR = (255, 150, 0)        # Orange
GRENADE_COLOR = (100, 255, 100)      # Green for grenade
GRENADE_EXPLOSION_COLOR = (255, 200, 0) # Yellow for explosion
TEXT_COLOR = (220, 220, 220)
WALL_COLOR = (100, 100, 120)
PARTICLE_COLORS = [(255, 100, 100), (255, 200, 100), (255, 150, 50)]
UI_BG = (30, 30, 50, 180)
BOSS_COLOR = (180, 50, 180)  # 新增BOSS颜色
BOSS_EXPLOSION_COLOR = (255, 100, 255)  # BOSS爆炸颜色

# 加载音效
shoot_sounds = [
    load_sound("shoot1.wav"),  # 手枪射击
    load_sound("shoot2.wav"),  # 霰弹枪射击
    load_sound("grenade_throw.wav")  # 手雷投掷
]
explosion_sound = load_sound("explosion.wav")
enemy_shoot_sound = load_sound("enemy_shoot.wav")
player_hit_sound = load_sound("player_hit.wav")
powerup_sound = load_sound("powerup.wav")
weapon_switch_sound = load_sound("weapon_switch.wav")
skill_activate_sound = load_sound("skill_activate.wav")
boss_spawn_sound = load_sound("striking.wav")  # 使用现有音效作为BOSS出现音效
boss_roar_sound = load_sound("roar.wav")  # 使用爆炸音效作为BOSS咆哮音效

# 设置音量
for sound in shoot_sounds:
    sound.set_volume(0.4)
explosion_sound.set_volume(0.6)
enemy_shoot_sound.set_volume(0.3)
player_hit_sound.set_volume(0.5)
powerup_sound.set_volume(0.5)
weapon_switch_sound.set_volume(0.4)
skill_activate_sound.set_volume(0.5)
boss_spawn_sound.set_volume(0.9)
boss_roar_sound.set_volume(0.8)

# Player settings
class Player:
    def __init__(self):
        self.x = WIDTH // 2
        self.y = HEIGHT - 50
        self.radius = 20
        self.speed = 5
        self.health = 100
        self.score = 0
        self.gun_cooldown = 0
        self.flash = 0
        self.weapon = 0  # 0: Pistol, 1: Shotgun, 2: Grenade
        self.weapon_colors = [PLAYER_BULLET_COLOR, SHOTGUN_COLOR, GRENADE_COLOR]
        self.weapon_names = ["Pistol", "Shotgun", "Grenade"]
        self.shield = 0
        self.shield_max = 50
        # Skill: Attack speed boost
        self.attack_boost_active = False
        self.attack_boost_duration = 0
        self.attack_boost_cooldown = 0
        self.collision_cooldown = 0  # Cooldown for collision damage
        self.grenade_cooldown = 0  # Specific cooldown for grenade
    
    def draw(self):
        # 绘制玩家主体
        pygame.draw.circle(screen, PLAYER_COLOR, (self.x, self.y), self.radius)
        
        # 添加细节
        pygame.draw.circle(screen, (0, 150, 200), (self.x, self.y), self.radius - 5)
        
        # 绘制方向指示器
        pygame.draw.polygon(screen, (200, 240, 255), [
            (self.x, self.y - self.radius - 5),
            (self.x - 5, self.y - self.radius - 15),
            (self.x + 5, self.y - self.radius - 15)
        ])
        
        # 护盾效果
        if self.shield > 0:
            shield_alpha = int(150 * (self.shield / self.shield_max))
            pygame.draw.circle(screen, (100, 200, 255, shield_alpha), 
                              (self.x, self.y), self.radius + 8, 3)
            
            # 添加护盾动画
            for i in range(8):
                angle = pygame.time.get_ticks() / 100 + i * math.pi/4
                x = self.x + (self.radius + 5) * math.cos(angle)
                y = self.y + (self.radius + 5) * math.sin(angle)
                pygame.draw.circle(screen, (200, 230, 255), (x, y), 3)
    
    def move(self, keys, walls):
        keys = pygame.key.get_pressed()
        dx, dy = 0, 0
        
        if keys[pygame.K_a] and self.x > self.radius:  # A key left
            dx = -self.speed
        if keys[pygame.K_d] and self.x < WIDTH - self.radius:  # D key right
            dx = self.speed
        if keys[pygame.K_w] and self.y > self.radius:  # W key up
            dy = -self.speed
        if keys[pygame.K_s] and self.y < HEIGHT - self.radius:  # S key down
            dy = self.speed
        
        # Check wall collisions
        if dx != 0 or dy != 0:
            new_rect = pygame.Rect(self.x - self.radius + dx, self.y - self.radius + dy, 
                                  self.radius * 2, self.radius * 2)
            
            collision = False
            for wall in walls:
                if new_rect.colliderect(wall.rect):
                    collision = True
                    break
            
            if not collision:
                self.x += dx
                self.y += dy
    
    def shoot(self, bullets, grenades):
        # Apply attack speed boost multiplier (not for grenade)
        cooldown_multiplier = 0.5 if self.attack_boost_active and self.weapon != 2 else 1.0
        
        if self.weapon == 0:  # Pistol
            if self.gun_cooldown == 0:
                bullets.append(Bullet(self.x, self.y - 30, -10, PLAYER_BULLET_COLOR, "player"))
                self.gun_cooldown = int(15 * cooldown_multiplier)
                # 播放手枪射击音效
                shoot_sounds[0].play()
                return True
        elif self.weapon == 1:  # Shotgun
            if self.gun_cooldown == 0:
                bullets.append(Bullet(self.x - 10, self.y - 30, -10, SHOTGUN_COLOR, "player", 8))
                bullets.append(Bullet(self.x, self.y - 30, -12, SHOTGUN_COLOR, "player", 8))
                bullets.append(Bullet(self.x + 10, self.y - 30, -10, SHOTGUN_COLOR, "player", 8))
                self.gun_cooldown = int(30 * cooldown_multiplier)
                # 播放霰弹枪射击音效
                shoot_sounds[1].play()
                return True
        elif self.weapon == 2:  # Grenade
            if self.gun_cooldown == 0 and self.grenade_cooldown == 0:
                grenades.append(Grenade(self.x, self.y - 30, -8, GRENADE_COLOR, "player"))
                self.gun_cooldown = 20  # Small delay before next shot of any weapon
                self.grenade_cooldown = 600  # 10 seconds at 60 FPS
                # 播放手雷投掷音效
                shoot_sounds[2].play()
                return True
        return False
    
    def update_skills(self):
        # 更新闪光效果
        if self.flash > 0:
            self.flash -= 1  # 每帧减少闪光计数器

        # Update attack boost duration
        if self.attack_boost_active:
            self.attack_boost_duration -= 1
            if self.attack_boost_duration <= 0:
                self.attack_boost_active = False
        
        # Update cooldowns
        if self.attack_boost_cooldown > 0:
            self.attack_boost_cooldown -= 1
        
        if self.collision_cooldown > 0:
            self.collision_cooldown -= 1
            
        if self.gun_cooldown > 0:
            self.gun_cooldown -= 1
            
        if self.grenade_cooldown > 0:
            self.grenade_cooldown -= 1
    
    def activate_attack_boost(self):
        if self.attack_boost_cooldown == 0:
            self.attack_boost_active = True
            self.attack_boost_duration = 300  # 5 seconds
            self.attack_boost_cooldown = 900   # 15 seconds cooldown
            return True
        return False
    
    def take_damage(self, amount):
        if self.shield > 0:
            self.shield -= amount
            if self.shield < 0:
                self.health += self.shield  # Negative shield becomes damage
                self.shield = 0
        else:
            self.health -= amount
        self.flash = 5  # Set hit flash effect
        # 播放玩家受伤音效
        player_hit_sound.play()
    
    def switch_weapon(self, direction):
        self.weapon = (self.weapon + direction) % 3
        if self.weapon < 0:
            self.weapon = 2
        # 播放武器切换音效
        weapon_switch_sound.play()
    
    def add_shield(self, amount):
        self.shield = min(self.shield_max, self.shield + amount)

# Enemy class
class Enemy:
    def __init__(self, walls):
        self.radius = 18
        self.speed = random.uniform(1.0, 2.5)
        self.shoot_cooldown = random.randint(30, 120)
        self.color = random.randint(200, 255), random.randint(50, 100), random.randint(50, 100)
        self.health = 50
        self.max_health = 50
        self.original_speed = self.speed
        self.direction = random.choice([-1, 1])  # Random initial direction
        self.stuck_timer = 0
        self.collision_cooldown = 0  # Cooldown for collision damage
        self.flash = 0  # 被击中时闪烁计时器
        
        # Find valid spawn position
        valid_position = False
        attempts = 0
        while not valid_position and attempts < 100:
            attempts += 1
            self.x = random.randint(self.radius, WIDTH - self.radius)
            self.y = random.randint(self.radius, HEIGHT // 2)
            
            # Check if not colliding with walls
            enemy_rect = pygame.Rect(self.x - self.radius, self.y - self.radius, 
                                    self.radius * 2, self.radius * 2)
            valid_position = True
            for wall in walls:
                if enemy_rect.colliderect(wall.rect):
                    valid_position = False
                    break
    
    def draw(self,player):
        # 绘制敌人主体
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)
        
        # 添加敌人细节（眼睛）
        eye_offset = 6
        pygame.draw.circle(screen, (255, 255, 255), (self.x - eye_offset, self.y - 5), 5)
        pygame.draw.circle(screen, (255, 255, 255), (self.x + eye_offset, self.y - 5), 5)
        
        # 添加动态瞳孔
        look_angle = math.atan2(player.y - self.y, player.x - self.x)
        pupil_offset = 2
        pupil_x1 = self.x - eye_offset + pupil_offset * math.cos(look_angle)
        pupil_y1 = self.y - 5 + pupil_offset * math.sin(look_angle)
        pupil_x2 = self.x + eye_offset + pupil_offset * math.cos(look_angle)
        pupil_y2 = self.y - 5 + pupil_offset * math.sin(look_angle)
        
        pygame.draw.circle(screen, (0, 0, 0), (pupil_x1, pupil_y1), 2)
        pygame.draw.circle(screen, (0, 0, 0), (pupil_x2, pupil_y2), 2)
        
        # 绘制愤怒表情（低血量时）
        if self.health < self.max_health * 0.3:
            pygame.draw.arc(screen, (255, 50, 50), 
                           [self.x - 10, self.y + 5, 20, 10], 
                           0, math.pi, 2)
        
        # 添加血条绘制 - 修复敌军生命值显示问题
        bar_width = 40
        bar_height = 5
        health_percent = self.health / self.max_health
        pygame.draw.rect(screen, (100, 0, 0), (self.x - bar_width//2, self.y + self.radius + 5, bar_width, bar_height))
        pygame.draw.rect(screen, (0, 200, 0), (self.x - bar_width//2, self.y + self.radius + 5, bar_width * health_percent, bar_height))
    
    def move(self, walls, player):
        dx = self.speed * self.direction
        
        # Check wall collisions
        new_rect = pygame.Rect(self.x - self.radius + dx, self.y - self.radius, 
                              self.radius * 2, self.radius * 2)
        
        collision = False
        for wall in walls:
            if new_rect.colliderect(wall.rect):
                collision = True
                break
        
        if collision:
            # Change direction if colliding
            self.direction *= -1
            self.stuck_timer += 1
        else:
            # Move normally
            self.x += dx
            self.stuck_timer = 0
        
        # If stuck for too long, try to move vertically
        if self.stuck_timer > 30:
            self.y += self.speed
            self.stuck_timer = 0
        
        # Boundary check - prevent enemies from leaving the screen
        if self.x < self.radius:
            self.x = self.radius
            self.direction = 1
        elif self.x > WIDTH - self.radius:
            self.x = WIDTH - self.radius
            self.direction = -1
        
        if self.y < self.radius:
            self.y = self.radius
        elif self.y > HEIGHT - self.radius:
            self.y = HEIGHT - self.radius
        
        # Check collision with player
        if self.collision_cooldown == 0:
            distance = math.sqrt((self.x - player.x) ** 2 + (self.y - player.y) ** 2)
            if distance < self.radius + player.radius:
                player.take_damage(5)  # Damage to player
                self.health -= 10       # Damage to enemy
                self.collision_cooldown = 30  # 0.5 second cooldown
                player.collision_cooldown = 30

                # 检查敌人是否死亡
                if self.health <= 0:
                    return True, False, True
                
                # 检查玩家是否死亡
                if player.health <= 0:
                    return True, True, False  # (collision occurred, player died)
                    
                return True, False, False  # (collision occurred, player alive)
        else:
            self.collision_cooldown -= 1
        return False, False, False  # (no collision, player alive)
    
    def shoot(self, bullets):
        if self.shoot_cooldown <= 0:
            bullets.append(Bullet(self.x, self.y + 30, 5, ENEMY_BULLET_COLOR, "enemy"))
            self.shoot_cooldown = random.randint(60, 180)
            # 播放敌人射击音效
            enemy_shoot_sound.play()
            return True
        return False

# Bullet class
class Bullet:
    def __init__(self, x, y, speed, color, owner, size=5):
        self.x = x
        self.y = y
        self.radius = size
        self.speed = speed
        self.color = color
        self.owner = owner  # "player" or "enemy"
        self.trail = []
    
    def draw(self):
        # 根据子弹类型绘制不同效果
        if self.owner == "player":
            # 玩家子弹 - 带有拖尾的发光效果
            for i, pos in enumerate(reversed(self.trail)):
                alpha = 200 - i * 40
                size = max(1, self.radius * (1 - i/len(self.trail)))
                pygame.draw.circle(screen, (*self.color, alpha), pos, size)
            
            # 子弹核心
            pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)
            
            # 添加高光
            pygame.draw.circle(screen, (255, 255, 255), 
                             (self.x - 2, self.y - 2), self.radius // 2)
        else:
            # 敌人子弹 - 带有红色光晕
            pygame.draw.circle(screen, (255, 100, 100, 150), 
                             (self.x, self.y), self.radius + 2)
            pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)
            pygame.draw.circle(screen, (255, 150, 150), 
                             (self.x, self.y), self.radius // 2)
    
    def move(self):
        self.y += self.speed
    
    def off_screen(self):
        return self.y < 0 or self.y > HEIGHT
    
    def collide_with_player(self, player):
        distance = math.sqrt((self.x - player.x) ** 2 + (self.y - player.y) ** 2)
        return distance < self.radius + player.radius
    
    def collide_with_enemy(self, enemy):
        distance = math.sqrt((self.x - enemy.x) ** 2 + (self.y - enemy.y) ** 2)
        return distance < self.radius + enemy.radius
    
    def collide_with_wall(self, wall):
        # Check if bullet collides with wall
        bullet_rect = pygame.Rect(self.x - self.radius, self.y - self.radius, 
                                 self.radius * 2, self.radius * 2)
        return bullet_rect.colliderect(wall.rect)

# 手雷类
class Grenade:
    def __init__(self, x, y, speed, color, owner):
        self.x = x
        self.y = y
        self.radius = 8  # 手雷本身的半径
        self.speed = speed
        self.color = color
        self.owner = owner
        self.timer = 30  # 1.5秒后爆炸 (60帧/秒)
        self.exploded = False
        self.explosion_radius = 155  # 爆炸半径
        self.explosion_damage = 50  # 手雷伤害
        self.trail = []
        self.warning_timer = 30  # 最后0.5秒开始闪烁警告
    
    def draw(self):
        # 绘制轨迹
        for i, pos in enumerate(self.trail):
            alpha = 200 * (1 - i/len(self.trail))
            trail_color = (*self.color, alpha)
            pygame.draw.circle(screen, trail_color, pos, max(1, self.radius * (1 - i/len(self.trail))))
        
        # 绘制手雷
        if not self.exploded:
            # 在爆炸前最后0.5秒闪烁
            if self.timer < self.warning_timer and self.timer % 6 < 3:
                flash_color = (255, 100, 100)  # 红色闪烁
            else:
                flash_color = self.color
                
            pygame.draw.circle(screen, flash_color, (self.x, self.y), self.radius)
            pygame.draw.circle(screen, (200, 200, 200), (self.x, self.y), self.radius - 2)
            
            # 绘制引信
            pygame.draw.rect(screen, (150, 150, 150), (self.x - 2, self.y - 10, 4, 6))
        
        # 绘制爆炸效果
        if self.exploded:
            # 爆炸核心
            pygame.draw.circle(screen, GRENADE_EXPLOSION_COLOR, (self.x, self.y), self.explosion_radius // 2)
            
            # 爆炸冲击波
            pygame.draw.circle(screen, (255, 150, 0, 150), (self.x, self.y), self.explosion_radius, 3)
            
            # 爆炸粒子
            for i in range(20):
                angle = random.uniform(0, 2 * math.pi)
                dist = random.uniform(0, self.explosion_radius)
                px = self.x + dist * math.cos(angle)
                py = self.y + dist * math.sin(angle)
                pygame.draw.circle(screen, (255, 200, 100), (int(px), int(py)), 3)
    
    def update(self):
        if not self.exploded:
            # 移动手雷
            self.y += self.speed
            
            # 添加轨迹点
            self.trail.append((self.x, self.y))
            if len(self.trail) > 5:
                self.trail.pop(0)
            
            # 减少计时器
            self.timer -= 1
            
            # 检查是否碰到边界
            if self.x < 0 or self.x > WIDTH or self.y < 0 or self.y > HEIGHT:
                self.exploded = True
                return True
            
            # 检查是否计时结束
            if self.timer <= 0:
                self.exploded = True
                return True
        return False
    
    def check_explosion_collision(self, entities):
        damaged_entities = []
        if self.exploded:
            for entity in entities:
                # 计算与爆炸中心的距离
                distance = math.sqrt((self.x - entity.x) ** 2 + (self.y - entity.y) ** 2)
                
                # 如果在爆炸范围内
                if distance < self.explosion_radius + entity.radius:
                    damaged_entities.append(entity)
        
        return damaged_entities

# BOSS类
class Boss:
    def __init__(self):
        self.radius = 45
        self.x = WIDTH // 2
        self.y = HEIGHT // 4
        self.speed_x = random.choice([-3, 3])
        self.speed_y = random.choice([-3, 3])
        self.health = 500
        self.max_health = 500
        self.explosion_cooldown = 0
        self.explosion_timer = 420  # 每5秒爆炸一次
        self.flash = 0
        self.collision_cooldown = 0
        self.immune_chance = 0.2  # 概率免疫子弹伤害
        self.spawn_effect_timer = 60  # 出现特效计时器
        self.charge_timer = 0
        self.charge_direction = (0, 0)
        self.is_charging = False
        self.charge_speed = 8
        self.charge_cooldown = 0
    
    def draw(self):
        # 绘制BOSS
        if self.spawn_effect_timer > 0:
            # 出现特效 - 脉动效果
            pulse = abs(math.sin(self.spawn_effect_timer * 0.1)) * 10
            color = (min(255, 180 + int(pulse * 7)), 50, min(255, 180 + int(pulse * 7)))
            pygame.draw.circle(screen, color, (self.x, self.y), self.radius + int(pulse))
            
            # 绘制BOSS核心
            pygame.draw.circle(screen, BOSS_COLOR, (self.x, self.y), self.radius)
        else:
            if self.flash > 0:
                color = (255, 255, 200)
                self.flash -= 1
            else:
                color = BOSS_COLOR
                
            pygame.draw.circle(screen, color, (self.x, self.y), self.radius)
            
            # 绘制BOSS细节
            pygame.draw.circle(screen, (100, 0, 100), (self.x, self.y), self.radius - 8)
            
            # 绘制BOSS眼睛
            pygame.draw.circle(screen, (255, 50, 50), (self.x - 15, self.y - 10), 12)
            pygame.draw.circle(screen, (255, 50, 50), (self.x + 15, self.y - 10), 12)
            pygame.draw.circle(screen, (0, 0, 0), (self.x - 15, self.y - 10), 6)
            pygame.draw.circle(screen, (0, 0, 0), (self.x + 15, self.y - 10), 6)
            
            # 绘制BOSS角
            pygame.draw.polygon(screen, (150, 0, 150), [
                (self.x - 20, self.y - 40),
                (self.x - 30, self.y - 60),
                (self.x - 10, self.y - 45)
            ])
            pygame.draw.polygon(screen, (150, 0, 150), [
                (self.x + 20, self.y - 40),
                (self.x + 30, self.y - 60),
                (self.x + 10, self.y - 45)
            ])
            
            # 绘制BOSS嘴巴
            pygame.draw.arc(screen, (255, 50, 50), 
                           [self.x - 20, self.y, 40, 30], 
                           math.pi, 2 * math.pi, 3)
        
        # 绘制血条
        bar_width = 150
        bar_height = 15
        pygame.draw.rect(screen, (100, 0, 0), (self.x - bar_width//2, self.y - self.radius - 30, bar_width, bar_height))
        pygame.draw.rect(screen, (0, 200, 0), (self.x - bar_width//2, self.y - self.radius - 30, 
                                              bar_width * (self.health / self.max_health), bar_height))
        pygame.draw.rect(screen, (200, 200, 200), (self.x - bar_width//2, self.y - self.radius - 30, bar_width, bar_height), 2)
        
        # 绘制BOSS名称
        font = pygame.font.SysFont(None, 30)
        name_text = font.render("BOSS", True, (255, 100, 255))
        screen.blit(name_text, (self.x - name_text.get_width() // 2, self.y - self.radius - 50))
        
        # 绘制爆炸冷却指示器
        if self.explosion_cooldown > 0:
            cooldown_percent = self.explosion_cooldown / self.explosion_timer
            pygame.draw.arc(screen, (255, 100, 255), 
                           [self.x - 30, self.y - 30, 60, 60], 
                           math.pi * 1.5, math.pi * 1.5 + math.pi * 2 * (1 - cooldown_percent), 5)
    
    def move(self):
        if self.spawn_effect_timer > 0:
            self.spawn_effect_timer -= 1
            return
        
        # 冲锋状态
        if self.is_charging:
            # 保存当前位置用于边界检测
            new_x = self.x + self.charge_direction[0] * self.charge_speed
            new_y = self.y + self.charge_direction[1] * self.charge_speed
            
            # 边界检测 - 确保BOSS不会移出屏幕
            if (self.radius <= new_x <= WIDTH - self.radius and 
                self.radius <= new_y <= HEIGHT - self.radius):
                self.x = new_x
                self.y = new_y
            
            # 检查冲锋结束
            self.charge_timer -= 1
            if self.charge_timer <= 0:
                self.is_charging = False
                self.charge_cooldown = 120  # 2秒冷却
        else:
            # 正常移动
            self.x += self.speed_x
            self.y += self.speed_y
            
            # 边界反弹
            if self.x <= self.radius or self.x >= WIDTH - self.radius:
                self.speed_x *= -1
            if self.y <= self.radius or self.y >= HEIGHT - self.radius:
                self.speed_y *= -1
            
            # 随机改变方向
            if random.random() < 0.01:
                self.speed_x = random.choice([-3, -2, 2, 3])
            if random.random() < 0.01:
                self.speed_y = random.choice([-3, -2, 2, 3])
            
            # 冲锋冷却
            if self.charge_cooldown > 0:
                self.charge_cooldown -= 1
            
            # 尝试发起冲锋
            if self.charge_cooldown <= 0 and random.random() < 0.02:
                self.start_charge()
    
    def start_charge(self):
        self.is_charging = True
        self.charge_timer = 60  # 冲锋持续1秒
    
        # 随机选择冲锋类型：直线冲锋或追踪玩家
        charge_type = random.choice(["straight", "player_track"])
        
        if charge_type == "straight":
            # 随机选择一个方向
            angle = random.uniform(0, 2 * math.pi)
            self.charge_direction = (math.cos(angle), math.sin(angle))
        else:
            pass
        
    def update_explosion(self, player, walls):
        if self.spawn_effect_timer > 0:
            return False
        
        self.explosion_cooldown += 1
        if self.explosion_cooldown >= self.explosion_timer:
            self.explosion_cooldown = 0
            return True
        return False
    
    def create_explosion(self):
        # 创建BOSS爆炸效果
        explosion = {
            "x": self.x,
            "y": self.y,
            "radius": 0,
            "max_radius": 200,
            "damage": 37, 
            "active": True,
            "damaged_player": False
        }
        return explosion
    
    def take_damage(self, amount, damage_type="bullet"):
        # 免疫子弹伤害的概率
        if damage_type == "bullet" and random.random() < self.immune_chance:
            return False  # 免疫伤害
        
        # 手雷伤害完全有效
        self.health -= amount
        self.flash = 5
        return True
    
    def collide_with_player(self, player):
        distance = math.sqrt((self.x - player.x) ** 2 + (self.y - player.y) ** 2)
        return distance < self.radius + player.radius
    
    def collision_damage(self, player):
        # 冲锋状态造成更高伤害
        if self.is_charging:
            player.take_damage(20)
        else:
            player.take_damage(10)
        
        # 碰撞后反弹
        self.speed_x *= -1
        self.speed_y *= -1
        self.collision_cooldown = 30  # 0.5秒冷却

# Explosion particle effect
class Particle:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.size = random.randint(2, 6)
        self.speed_x = random.uniform(-3, 3)
        self.speed_y = random.uniform(-3, 3)
        self.life = random.randint(20, 40)
    
    def update(self):
        self.x += self.speed_x
        self.y += self.speed_y
        self.life -= 1
        self.size = max(0, self.size - 0.1)
        return self.life > 0
    
    def draw(self):
        # 根据粒子类型绘制不同效果
        if self.color == GRENADE_EXPLOSION_COLOR:
            # 爆炸粒子 - 带有发光效果
            pygame.draw.circle(screen, (255, 200, 100, self.life * 6), 
                             (int(self.x), int(self.y)), int(self.size))
            pygame.draw.circle(screen, (255, 150, 50, self.life * 3), 
                             (int(self.x), int(self.y)), int(self.size * 1.5), 1)
        else:
            # 普通粒子
            alpha = min(255, self.life * 6)
            pygame.draw.circle(screen, (*self.color, alpha), 
                             (int(self.x), int(self.y)), int(self.size))

# Wall class (obstacles)
class Wall:
    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        self.color = WALL_COLOR
        self.border_color = (80, 80, 100)
    
    def draw(self):
        pygame.draw.rect(screen, self.color, self.rect)
        pygame.draw.rect(screen, self.border_color, self.rect, 2)
        
        # Add wall texture
        for i in range(0, self.rect.width, 10):
            for j in range(0, self.rect.height, 10):
                if (i//10 + j//10) % 2 == 0:
                    pygame.draw.rect(screen, (90, 90, 110), 
                                    (self.rect.x + i, self.rect.y + j, 5, 5))
    
    def block_bullet(self, bullet):
        # 30% chance to block the bullet
        if random.random() < 0.3:
            return True
        return False

# Power-up class
class PowerUp:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = 12
        self.type = random.choice(["health", "shield", "points"])
        self.timer = 300  # 5 seconds at 60 FPS
        self.float_offset = random.uniform(0, math.pi * 2)
    
    def draw(self):
        # 添加浮动效果
        float_y = self.y + math.sin(pygame.time.get_ticks() / 200 + self.float_offset) * 5
        
        if self.type == "health":
            color = (0, 200, 0)
        elif self.type == "shield":
            color = (100, 200, 255)
        else:  # points
            color = (255, 215, 0)
        
        # 绘制主体
        pygame.draw.circle(screen, color, (self.x, float_y), self.radius)
        pygame.draw.circle(screen, (200, 200, 200), (self.x, float_y), self.radius, 2)
        
        # 添加脉冲效果
        pulse = abs(math.sin(pygame.time.get_ticks() / 200)) * 2
        pygame.draw.circle(screen, (*color, 50), (self.x, float_y), self.radius + pulse)
        
        # Draw symbol
        if self.type == "health":
            pygame.draw.rect(screen, (255, 255, 255), (self.x - 4, float_y - 8, 8, 16))
            pygame.draw.polygon(screen, (255, 255, 255), 
                              [(self.x, float_y - 10), (self.x - 6, float_y + 2), (self.x + 6, float_y + 2)])
        elif self.type == "shield":
            pygame.draw.circle(screen, (255, 255, 255), (self.x, float_y), 6, 2)
        else:  # points
            pygame.draw.circle(screen, (255, 255, 255), (self.x, float_y), 6)
    
    def update(self):
        self.timer -= 1
        return self.timer > 0
    
    def collide_with_player(self, player):
        distance = math.sqrt((self.x - player.x) ** 2 + (self.y - player.y) ** 2)
        return distance < self.radius + player.radius

# 暂停菜单类
class PauseMenu:
    def __init__(self):
        self.visible = False
        self.continue_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 - 50, 200, 60)
        self.quit_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 50, 200, 60)
        
    def draw(self):
        # 半透明背景
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))
        
        # 绘制菜单框
        menu_rect = pygame.Rect(WIDTH//2 - 150, HEIGHT//2 - 100, 300, 250)
        pygame.draw.rect(screen, (40, 40, 80), menu_rect, border_radius=15)
        pygame.draw.rect(screen, (80, 80, 120), menu_rect, 3, border_radius=15)
        
        # 标题
        title_font = pygame.font.SysFont(None, 48)
        title = title_font.render("PAUSED", True, (255, 215, 0))
        screen.blit(title, (WIDTH//2 - title.get_width()//2, HEIGHT//2 - 130))
        
        # 绘制按钮
        mouse_pos = pygame.mouse.get_pos()
        continue_hover = self.continue_button.collidepoint(mouse_pos)
        quit_hover = self.quit_button.collidepoint(mouse_pos)
        
        # 继续按钮
        continue_color = (100, 200, 100) if continue_hover else (70, 160, 70)
        pygame.draw.rect(screen, continue_color, self.continue_button, border_radius=10)
        pygame.draw.rect(screen, (150, 250, 150), self.continue_button, 3, border_radius=10)
        continue_text = pygame.font.SysFont(None, 36).render("CONTINUE", True, (255, 255, 255))
        screen.blit(continue_text, (self.continue_button.centerx - continue_text.get_width()//2, 
                                   self.continue_button.centery - continue_text.get_height()//2))
        
        # 退出按钮
        quit_color = (200, 100, 100) if quit_hover else (160, 70, 70)
        pygame.draw.rect(screen, quit_color, self.quit_button, border_radius=10)
        pygame.draw.rect(screen, (250, 150, 150), self.quit_button, 3, border_radius=10)
        quit_text = pygame.font.SysFont(None, 36).render("QUIT", True, (255, 255, 255))
        screen.blit(quit_text, (self.quit_button.centerx - quit_text.get_width()//2, 
                              self.quit_button.centery - quit_text.get_height()//2))
        
        # 提示信息
        info_font = pygame.font.SysFont(None, 24)
        info_text = info_font.render("Progress saved automatically", True, (180, 180, 200))
        screen.blit(info_text, (WIDTH//2 - info_text.get_width()//2, HEIGHT//2 + 120))
    
    def handle_event(self, event, player, enemies, wave, score):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.continue_button.collidepoint(event.pos):
                self.visible = False
                return True  # 继续游戏
            elif self.quit_button.collidepoint(event.pos):
                # 保存游戏状态但不记录分数
                GameData.save_game_state({
                    "player": {
                        "x": player.x,
                        "y": player.y,
                        "health": player.health,
                        "shield": player.shield,
                        "weapon": player.weapon,
                        "score": player.score,
                        "attack_boost_active": player.attack_boost_active,
                        "attack_boost_duration": player.attack_boost_duration,
                        "attack_boost_cooldown": player.attack_boost_cooldown,
                        "grenade_cooldown": player.grenade_cooldown
                    },
                    "enemies": [{"x": e.x, "y": e.y, "health": e.health} for e in enemies],
                    "wave": wave,
                    "score": score
                })
                return False  # 退出游戏
        return True

# Game main function
def main(load_saved_state=False):
    clock = pygame.time.Clock()
    player = Player()
    bullets = []
    grenades = []  # 新增手雷列表
    enemy_bullets = []
    particles = []
    powerups = []
    record_saved = False
    
    # Create walls
    walls = [
        Wall(100, 200, 80, 20),
        Wall(300, 150, 20, 100),
        Wall(500, 250, 120, 20),
        Wall(200, 400, 20, 80),
        Wall(600, 350, 80, 20),
        Wall(150, 500, 200, 20),
        Wall(450, 100, 20, 80)
    ]
    
    # Create enemies with valid positions
    enemies = []
    for _ in range(5):
        enemies.append(Enemy(walls))
    
    # BOSS相关变量
    boss = None
    boss_explosions = []  # BOSS爆炸效果
    boss_warning_timer = 0  # BOSS出现警告计时器
    boss_spawned = False
    
    font = pygame.font.SysFont(None, 36)
    small_font = pygame.font.SysFont(None, 24)
    game_over = False
    enemy_spawn_timer = 0
    powerup_timer = 0
    shake_time = 0
    shake_intensity = 0
    shake_offset = (0, 0)
    max_enemies = 15
    wave = 1
    enemy_kills = 0
    player_died_from_explosion = False
    player_died_from_collision = False

    # 初始化暂停菜单
    pause_menu = PauseMenu()
    
    # 如果加载保存的状态
    if load_saved_state:
        saved_state = GameData.load_game_state()
        if saved_state:
            # 恢复玩家状态
            player.x = saved_state["player"]["x"]
            player.y = saved_state["player"]["y"]
            player.health = saved_state["player"]["health"]
            player.shield = saved_state["player"]["shield"]
            player.weapon = saved_state["player"]["weapon"]
            player.score = saved_state["player"]["score"]
            player.attack_boost_active = saved_state["player"]["attack_boost_active"]
            player.attack_boost_duration = saved_state["player"]["attack_boost_duration"]
            player.attack_boost_cooldown = saved_state["player"]["attack_boost_cooldown"]
            player.grenade_cooldown = saved_state["player"]["grenade_cooldown"]
            
            # 恢复敌人状态
            wave = saved_state["wave"]
            for enemy_data in saved_state["enemies"]:
                enemy = Enemy(walls)
                enemy.x = enemy_data["x"]
                enemy.y = enemy_data["y"]
                enemy.health = enemy_data["health"]
                enemies.append(enemy)
    
    # Draw background grid
    def draw_background():
        # 星空背景
        screen.fill(BACKGROUND)
        
        # 绘制静态星星
        for i in range(100):
            x = (i * 37) % WIDTH
            y = (i * 23) % HEIGHT
            size = random.randint(1, 2)
            brightness = random.randint(100, 200)
            pygame.draw.circle(screen, (brightness, brightness, 255), (x, y), size)
        
        # 绘制动态星星（流星效果）
        time = pygame.time.get_ticks() / 1000
        for i in range(5):
            speed = 0.5 + i * 0.2
            x = (time * speed * 50) % WIDTH
            y = (time * speed * 30 + i * 100) % HEIGHT
            
            # 绘制流星尾迹
            for j in range(10):
                pos_x = x - j * 3
                pos_y = y - j * 1.5
                alpha = 255 - j * 25
                size = max(1, 3 - j * 0.3)
                pygame.draw.circle(screen, (200, 200, 255, alpha), (int(pos_x), int(pos_y)), size)
        
        # 添加远处星云 - 使用更淡的颜色
        for i in range(3):
            x = WIDTH // 4 * (i + 1)
            y = HEIGHT // 3 + math.sin(time + i) * 20
            radius = 80 + math.sin(time * 0.5 + i) * 10
            alpha = 30 + math.sin(time * 0.3 + i) * 20

            # 创建透明表面
            cloud_surf = pygame.Surface((radius*2, radius*2), pygame.SRCALPHA)
            
            # 绘制透明圆形（使用更淡的紫色）
            pygame.draw.circle(cloud_surf, (180, 180, 240, alpha*3),  # 更淡的紫色
                            (radius, radius), radius)
            
            # 将透明表面绘制到屏幕上
            screen.blit(cloud_surf, (x - radius, y - radius))
    
    # Draw health bar
    def draw_health_bar(x, y, width, height, health, shield=0):
        # 绘制背景
        pygame.draw.rect(screen, (50, 50, 80), (x, y, width, height))
        
        # 绘制生命条
        health_width = width * (health / 100)
        # 创建渐变效果
        for i in range(int(health_width)):
            color_value = int(200 * (i / health_width))
            pygame.draw.line(screen, (color_value, 200 - color_value//2, 50), 
                            (x + i, y), (x + i, y + height))
        
        # 绘制边框
        pygame.draw.rect(screen, (150, 150, 200), (x, y, width, height), 2)
        
        # 添加生命值文本
        health_text = small_font.render(f"{health}%", True, TEXT_COLOR)
        screen.blit(health_text, (x + width + 10, y))

        # 在血量条下方添加护盾条（高度为血量条的一半）
        shield_height = height // 2
        shield_y = y + height + 5  # 在血量条下方5像素处
        
        # 绘制护盾条背景
        pygame.draw.rect(screen, (30, 30, 60), (x, shield_y, width, shield_height))
        
        # 绘制护盾值
        if shield > 0:
            shield_width = width * (shield / player.shield_max)
            # 护盾条使用蓝色渐变
            for i in range(int(shield_width)):
                blue_value = min(255, 150 + int(100 * (i / shield_width)))
                pygame.draw.line(screen, (50, 150, blue_value), 
                                (x + i, shield_y), (x + i, shield_y + shield_height))
        
        # 绘制护盾条边框
        pygame.draw.rect(screen, (100, 150, 255), (x, shield_y, width, shield_height), 2)
        
        # 添加护盾值文本
        shield_text = small_font.render(f"Shield: {shield:.0f}/{player.shield_max}", True, (100, 200, 255))
        screen.blit(shield_text, (x + width + 10, shield_y))
    
    # 绘制武器指示器
    def draw_weapon_indicator(x, y, weapon_index, active=False):
        # 武器指示器
        colors = [PLAYER_BULLET_COLOR, SHOTGUN_COLOR, GRENADE_COLOR]
        names = ["Pistol", "Shotgun", "Grenade"]
        
        # 绘制底座
        pygame.draw.rect(screen, (40, 40, 60), (x, y, 120, 40), border_radius=5)
        
        for i in range(3):
            # 绘制武器图标
            icon_rect = pygame.Rect(x + 10 + i*40, y + 5, 30, 30)
            
            if i == weapon_index:
                # 当前武器高亮
                pygame.draw.rect(screen, (80, 80, 120), icon_rect, border_radius=5)
                pygame.draw.rect(screen, colors[i], icon_rect, 2, border_radius=5)
                
                # 添加脉冲效果
                pulse = abs(math.sin(pygame.time.get_ticks() / 200)) * 10
                pulse_rect = pygame.Rect(x + 5 + i*40, y, 40, 40)
                pygame.draw.rect(screen, (*colors[i], 50), pulse_rect, border_radius=8)
            else:
                pygame.draw.rect(screen, (60, 60, 80), icon_rect, border_radius=5)
            
            # 绘制武器简图
            if i == 0:  # 手枪
                pygame.draw.rect(screen, colors[i], (x+15+i*40, y+15, 20, 8))
            elif i == 1:  # 霰弹枪
                pygame.draw.rect(screen, colors[i], (x+15+i*40, y+15, 10, 8))
                pygame.draw.rect(screen, colors[i], (x+25+i*40, y+12, 5, 14))
            else:  # 手雷
                pygame.draw.circle(screen, colors[i], (x+25+i*40, y+20), 8)
    
    # Draw UI panel
    def draw_ui_panel():
        # Draw semi-transparent UI background
        ui_surface = pygame.Surface((WIDTH, 80), pygame.SRCALPHA)
        ui_surface.fill(UI_BG)
        screen.blit(ui_surface, (0, HEIGHT - 80))
        
        # Draw weapon info
        weapon_text = font.render(f"Weapon: {player.weapon_names[player.weapon]}", True, TEXT_COLOR)
        screen.blit(weapon_text, (20, HEIGHT - 70))
        
        # Draw weapon controls
        controls_text = small_font.render("Press 1, 2, 3 to switch weapons", True, (180, 180, 180))
        screen.blit(controls_text, (20, HEIGHT - 35))
        
        # Draw attack boost skill
        boost_text = small_font.render("Press F for Attack Boost", True, (200, 200, 100))
        screen.blit(boost_text, (450, HEIGHT - 35))

        input_warning = small_font.render("(Use Eng.input!)", True, (255, 100, 100))
        screen.blit(input_warning, (WIDTH - input_warning.get_width() - 20, HEIGHT - 35))
        
        # Draw attack boost cooldown
        pygame.draw.rect(screen, (50, 50, 80), (450, HEIGHT - 65, 150, 20))
        if player.attack_boost_cooldown > 0:
            cooldown_percent = 1 - (player.attack_boost_cooldown / 900)
            pygame.draw.rect(screen, (255, 200, 0), (450, HEIGHT - 65, 150 * cooldown_percent, 20))
        else:
            pygame.draw.rect(screen, (255, 200, 0), (450, HEIGHT - 65, 150, 20))
        pygame.draw.rect(screen, (150, 150, 50), (450, HEIGHT - 65, 150, 20), 2)
        
        if player.attack_boost_cooldown > 0:
            cooldown_text = small_font.render(f"Boost CD: {player.attack_boost_cooldown//60+1}s", True, TEXT_COLOR)
        elif player.attack_boost_active:
            cooldown_text = small_font.render("BOOST ACTIVE!", True, (255, 255, 100))
        else:
            cooldown_text = small_font.render("Attack Boost Ready", True, TEXT_COLOR)
        screen.blit(cooldown_text, (455, HEIGHT - 65))
        
        # Draw grenade cooldown
        if player.weapon == 2:
            pygame.draw.rect(screen, (50, 50, 80), (250, HEIGHT - 65, 150, 20))
            if player.grenade_cooldown > 0:
                cooldown_percent = 1 - (player.grenade_cooldown / 600)
                pygame.draw.rect(screen, (100, 255, 100), (250, HEIGHT - 65, 150 * cooldown_percent, 20))
            else:
                pygame.draw.rect(screen, (100, 255, 100), (250, HEIGHT - 65, 150, 20))
            pygame.draw.rect(screen, (50, 150, 50), (250, HEIGHT - 65, 150, 20), 2)
            
            if player.grenade_cooldown > 0:
                cooldown_text = small_font.render(f"Grenade CD: {player.grenade_cooldown//60+1}s", True, TEXT_COLOR)
            else:
                cooldown_text = small_font.render("Grenade Ready", True, TEXT_COLOR)
            screen.blit(cooldown_text, (255, HEIGHT - 65))
    
    # 绘制BOSS警告
    def draw_boss_warning():
        warning_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        alpha = abs(math.sin(boss_warning_timer * 0.2)) * 200
        warning_surface.fill((255, 50, 50, int(alpha)))
        screen.blit(warning_surface, (0, 0))
        
        warning_font = pygame.font.SysFont(None, 72)
        warning_text = warning_font.render("BOSS INCOMING!", True, (255, 255, 255))
        screen.blit(warning_text, (WIDTH//2 - warning_text.get_width()//2, HEIGHT//2 - 50))
        
        countdown = max(0, (boss_warning_timer - 30) // 30 + 1)
        countdown_text = font.render(f"{countdown}", True, (255, 255, 255))
        screen.blit(countdown_text, (WIDTH//2 - countdown_text.get_width()//2, HEIGHT//2 + 30))
    
    # 绘制BOSS爆炸效果
    def draw_boss_explosion(explosion):
        # 绘制爆炸核心
        pygame.draw.circle(screen, BOSS_EXPLOSION_COLOR, (explosion["x"], explosion["y"]), explosion["radius"])
        
        # 绘制冲击波
        pygame.draw.circle(screen, (255, 100, 255, 150), (explosion["x"], explosion["y"]), explosion["radius"], 5)
        
        # 绘制粒子
        for _ in range(5):
            angle = random.uniform(0, 2 * math.pi)
            dist = random.uniform(0, explosion["radius"])
            px = explosion["x"] + dist * math.cos(angle)
            py = explosion["y"] + dist * math.sin(angle)
            size = random.randint(3, 8)
            pygame.draw.circle(screen, (255, 200, 255), (int(px), int(py)), size)
    
    # 应用屏幕特效
    def apply_screen_effects():
        # 玩家受伤时的红色滤镜
        if player.flash > 0:
            # 根据闪光值计算透明度（从100到0）
            alpha = min(100, player.flash * 20)  # 闪光值5-0对应透明度100-0
            flash_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            flash_surf.fill((255, 50, 50, alpha))
            screen.blit(flash_surf, (0, 0))
        
        # BOSS战的紫色氛围
        if boss:
            boss_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            alpha = abs(math.sin(pygame.time.get_ticks() / 500)) * 50
            boss_surf.fill((180, 50, 180, alpha))
            screen.blit(boss_surf, (0, 0))
        
        # 攻击加速技能激活时的光效
        if player.attack_boost_active:
            boost_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            alpha = abs(math.sin(pygame.time.get_ticks() / 200)) * 100
            boost_surf.fill((255, 200, 0, alpha))
            screen.blit(boost_surf, (0, 0))

    # Create explosion effect
    def create_explosion(x, y, size=1.0):
        # 创建多层爆炸效果
        for i in range(int(30 * size)):
            # 核心粒子 - 亮黄色
            particles.append(Particle(x, y, (255, 220, 100)))
        
        for i in range(int(20 * size)):
            # 火焰粒子 - 橙红色
            particles.append(Particle(x, y, (255, 100, 50)))
        
        for i in range(int(10 * size)):
            # 烟雾粒子 - 灰色
            particles.append(Particle(x, y, (150, 150, 150)))
        
        # 添加冲击波效果
        for i in range(5):
            radius = i * 15
            alpha = 200 - i * 40
            pygame.draw.circle(screen, (255, 200, 100, alpha), (x, y), radius, 2)
        
        # 播放爆炸音效
        explosion_sound.play()

    # Main game loop
    return_to_menu = False  # 添加返回菜单标志
    
    while not return_to_menu:
        keys = pygame.key.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # 暂停菜单事件处理
            if pause_menu.visible:
                if not pause_menu.handle_event(event, player, enemies, wave, player.score):
                    return_to_menu = True
                continue

            if event.type == pygame.KEYDOWN:
                # 按M键暂停游戏
                if event.key == pygame.K_m:
                    pause_menu.visible = True
                if event.key == pygame.K_SPACE and not game_over:
                    player.shoot(bullets, grenades)  # 添加grenades参数
                if event.key == pygame.K_r and game_over:
                    # 设置返回菜单标志
                    return_to_menu = True
                    game_over = False
                if not game_over:
                    if event.key == pygame.K_1:
                        player.weapon = 0  # Pistol
                    elif event.key == pygame.K_2:
                        player.weapon = 1  # Shotgun
                    elif event.key == pygame.K_3:  # 新增武器3
                        player.weapon = 2  # Grenade
                    elif event.key == pygame.K_f:
                        if player.activate_attack_boost():
                            # Visual feedback for boost activation
                            for _ in range(30):
                                particles.append(Particle(
                                    player.x, player.y, 
                                    (255, 200, 0)
                                ))
                            # 播放技能激活音效
                            skill_activate_sound.play()
        
        # 如果设置了返回菜单标志，退出当前游戏循环
        if return_to_menu:
            return
        
        # 如果游戏暂停，跳过游戏逻辑
        if pause_menu.visible:
            # 绘制暂停菜单
            pause_menu.draw()
            pygame.display.flip()
            continue
        
        # Game over screen
        if game_over:
            draw_background()

            # 只在第一次进入游戏结束时保存记录
            if not record_saved:
                # 在游戏结束时保存记录
                GameData.add_record(player.score)
                record_saved = True
            
            # 添加"WASTED!"的大字
            death_text = font.render("WASTED!", True, (255, 50, 50))
            screen.blit(death_text, (WIDTH // 2 - death_text.get_width() // 2, HEIGHT // 2 - 150))
            
            # 添加游戏结束原因
            if player_died_from_collision:
                cause_text = font.render("Crushed by enemies", True, (200, 100, 100))
            elif player_died_from_explosion:
                cause_text = font.render("Blown up by grenade", True, (200, 100, 100))
            else:
                cause_text = font.render("Shot by enemies", True, (200, 100, 100))
            screen.blit(cause_text, (WIDTH // 2 - cause_text.get_width() // 2, HEIGHT // 2 - 100))
            
            game_over_text = font.render("GAME OVER!", True, (255, 50, 50))
            score_text = font.render(f"Final Score: {player.score}", True, TEXT_COLOR)
            wave_text = font.render(f"Wave: {wave}", True, TEXT_COLOR)
            restart_text = font.render("Press R to return to menu", True, TEXT_COLOR)
            
            screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2 - 40))
            screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))
            screen.blit(wave_text, (WIDTH // 2 - wave_text.get_width() // 2, HEIGHT // 2 + 40))
            screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 80))
            
            pygame.display.flip()
            continue  # 跳过游戏逻辑，停留在游戏结束画面
        
        # BOSS出现警告
        if boss_warning_timer > 0:
            boss_warning_timer -= 1
            if boss_warning_timer <= 0 and not boss_spawned:
                boss = Boss()
                boss_spawned = True
                # 播放BOSS出现音效
                boss_spawn_sound.play()
        
        # BOSS逻辑
        if boss and not game_over:
            # BOSS移动
            boss.move()
            
            # BOSS爆炸技能
            if boss.update_explosion(player, walls):
                boss_explosions.append(boss.create_explosion())
                # 播放BOSS咆哮音效
                boss_roar_sound.play()
            
            # 更新BOSS爆炸效果
            for explosion in boss_explosions[:]:
                explosion["radius"] += 5
                # 检查爆炸是否伤害玩家（仅当尚未造成伤害时）
                if not explosion["damaged_player"]:
                    distance = math.sqrt((player.x - explosion["x"])**2 + (player.y - explosion["y"])**2)
                    if distance < explosion["radius"] + player.radius:
                        player.take_damage(explosion["damage"])
                        explosion["damaged_player"] = True  # 标记为已造成伤害
                        
                        # 添加玩家死亡检查
                        if player.health <= 0:
                            game_over = True
                            player_died_from_explosion = True
                            create_explosion(player.x, player.y)
                if explosion["radius"] >= explosion["max_radius"]:
                    boss_explosions.remove(explosion)

            # 检查BOSS碰撞玩家
            if boss.collide_with_player(player) and boss.collision_cooldown <= 0:
                boss.collision_damage(player)
                if player.health <= 0:
                    game_over = True
                    player_died_from_collision = True
                    create_explosion(player.x, player.y)
            else:
                if boss.collision_cooldown > 0:
                    boss.collision_cooldown -= 1
        
        # Player movement with wall collision
        player.move(keys,walls)
        
        # Update player skills and cooldowns
        player.update_skills()
        
        # Spawn new enemies
        enemy_spawn_timer += 1
        if enemy_spawn_timer >= 120 and len(enemies) < max_enemies:
            enemies.append(Enemy(walls))
            enemy_spawn_timer = 0
        
        # Spawn powerups
        powerup_timer += 1
        if powerup_timer >= 600 and len(powerups) < 3:  # Every 10 seconds
            powerups.append(PowerUp(random.randint(50, WIDTH-50), random.randint(100, HEIGHT-100)))
            powerup_timer = 0
        
        # Enemy movement and shooting
        player_died_from_collision = False
        for enemy in enemies[:]:
            collision_occurred, player_died, enemy_died = enemy.move(walls, player)
            enemy.shoot_cooldown -= 1
            if enemy.shoot(enemy_bullets):
                pass
            if enemy_died:
                create_explosion(enemy.x, enemy.y)
                enemies.remove(enemy)
                player.score += 10  # 给予击杀分数
                enemy_kills += 1
                # 20% chance to drop powerup
                if random.random() < 0.2:
                    powerups.append(PowerUp(enemy.x, enemy.y))
                continue  # 跳过后续处理
            if player_died:
                player_died_from_collision = True
            elif collision_occurred:
                # Collision occurred but player didn't die
                create_explosion(enemy.x, enemy.y)
                shake_time = 5
                shake_intensity = 3
        
        # Check if player died from collision
        if player_died_from_collision:
            game_over = True
            # 为玩家死亡添加爆炸效果
            create_explosion(player.x, player.y)

        # Update powerups
        for powerup in powerups[:]:
            if not powerup.update():
                powerups.remove(powerup)
            elif powerup.collide_with_player(player):
                if powerup.type == "health":
                    player.health = min(100, player.health + 20)
                elif powerup.type == "shield":
                    player.add_shield(20)
                else:  # points
                    player.score += 50
                # 播放道具拾取音效
                powerup_sound.play()
                powerups.remove(powerup)
        
        # Update grenades
        for grenade in grenades[:]:
            if grenade.update():
                # 手雷爆炸
                create_explosion(grenade.x, grenade.y, 1.5)
                
                # 获取爆炸范围内的所有实体
                all_entities = enemies + [player]
                if boss:
                    all_entities.append(boss)
                damaged_entities = grenade.check_explosion_collision(all_entities)
                
                # 对范围内的实体造成伤害
                for entity in damaged_entities:
                    if entity in enemies:
                        entity.health -= grenade.explosion_damage
                        entity.flash = 5
                        if entity.health <= 0:
                            enemies.remove(entity)
                            player.score += 15  # 额外分数奖励
                            enemy_kills += 1
                    elif entity == player:
                        player.take_damage(grenade.explosion_damage // 2)  # 玩家受到一半伤害

                        # 添加玩家死亡检测
                        if player.health <= 0:
                            game_over = True
                            player_died_from_explosion = True
                            create_explosion(player.x, player.y)
                    elif boss and entity == boss:
                        # BOSS受到手雷伤害
                        if boss.take_damage(grenade.explosion_damage, "grenade"):
                            if boss.health <= 0:
                                create_explosion(boss.x, boss.y, 2.0)
                                player.score += 500  # 击败BOSS获得大量分数
                                boss = None
                                boss_spawned = False
                
                # 屏幕震动效果
                shake_time = 25
                shake_intensity = 15
        
        # Remove exploded grenades after one frame
        grenades = [g for g in grenades if not g.exploded]
        
        # Update bullet positions
        for bullet in bullets[:]:
            bullet.move()
            if bullet.off_screen():
                bullets.remove(bullet)
                continue
            
            # Check bullet collision with walls
            bullet_blocked = False
            for wall in walls:
                if bullet.collide_with_wall(wall) and wall.block_bullet(bullet):
                    create_explosion(bullet.x, bullet.y)
                    bullets.remove(bullet)
                    bullet_blocked = True
                    break
            
            if bullet_blocked:
                continue
            
            # Check bullet collision with enemies
            for enemy in enemies[:]:
                if bullet.collide_with_enemy(enemy):
                    enemy.health -= 10
                    if enemy.health <= 0:
                        create_explosion(enemy.x, enemy.y)
                        if bullet in bullets:
                            bullets.remove(bullet)
                        enemies.remove(enemy)
                        player.score += 10
                        enemy_kills += 1
                        # Screen shake effect
                        shake_time = 10
                        shake_intensity = 3
                        
                        # 20% chance to drop powerup
                        if random.random() < 0.2:
                            powerups.append(PowerUp(enemy.x, enemy.y))
                    break
            
            # 检查子弹是否击中BOSS
            if boss and bullet.collide_with_enemy(boss):
                if boss.take_damage(10):  # 有概率免疫
                    if boss.health <= 0:
                        create_explosion(boss.x, boss.y, 2.0)
                        player.score += 500  # 击败BOSS获得大量分数
                        boss = None
                        boss_spawned = False
                if bullet in bullets:
                    bullets.remove(bullet)

        for bullet in enemy_bullets[:]:
            bullet.move()
            if bullet.off_screen():
                enemy_bullets.remove(bullet)
                continue
            
            # Check bullet collision with walls
            bullet_blocked = False
            for wall in walls:
                if bullet.collide_with_wall(wall) and wall.block_bullet(bullet):
                    create_explosion(bullet.x, bullet.y)
                    enemy_bullets.remove(bullet)
                    bullet_blocked = True
                    break
            
            if bullet_blocked:
                continue
            
            # Check bullet collision with player
            if bullet.collide_with_player(player):
                player.take_damage(10)
                create_explosion(player.x, player.y)
                if bullet in enemy_bullets:
                    enemy_bullets.remove(bullet)
                if player.health <= 0:
                    game_over = True
        
        # Update particle effects
        particles = [p for p in particles if p.update()]
        
        # Check wave progression
        if enemy_kills >= wave * 10:
            wave += 1
            max_enemies = min(20, 5 + wave * 2)  # Increase max enemies per wave
            enemy_kills = 0
            
            # 在第二波及以后的波次生成BOSS（如果当前没有BOSS）
            if wave >= 4 and (int(wave)%2 == 0) and not boss and not boss_warning_timer and not boss_spawned:
                boss_warning_timer = 90  # 3秒警告
                # 播放警告音效
                boss_spawn_sound.play()
        
        # Screen shake effect
        if shake_time > 0:
            shake_offset = (random.randint(-shake_intensity, shake_intensity), 
                           random.randint(-shake_intensity, shake_intensity))
            shake_time -= 1
        else:
            shake_offset = (0, 0)
            shake_intensity = 0
        
        # Draw game
        draw_background()
        
        # Draw walls
        for wall in walls:
            wall.draw()
        
        # Draw enemies
        for enemy in enemies:
            enemy.draw(player)
        
        # Draw bullets
        for bullet in bullets:
            bullet.draw()
        
        for bullet in enemy_bullets:
            bullet.draw()
        
        # Draw grenades
        for grenade in grenades:
            grenade.draw()
        
        # Draw player
        player.draw()
        
        # Draw particles
        for particle in particles:
            particle.draw()
        
        # Draw powerups
        for powerup in powerups:
            powerup.draw()
        
        # Draw BOSS
        if boss:
            boss.draw()
        
        # Draw BOSS爆炸效果
        for explosion in boss_explosions:
            draw_boss_explosion(explosion)
        
        # Draw UI
        score_text = font.render(f"Score: {player.score}", True, TEXT_COLOR)
        wave_text = font.render(f"Wave: {wave}", True, TEXT_COLOR)
        screen.blit(score_text, (20, 25))
        screen.blit(wave_text, (WIDTH - wave_text.get_width() - 20, 20))
        
        # Draw enemy count
        enemies_text = small_font.render(f"Enemies: {len(enemies)}/{max_enemies}", True, (200, 150, 150))
        screen.blit(enemies_text, (WIDTH - enemies_text.get_width() - 20, 60))
        
        # Draw health bar
        draw_health_bar(150, 25, 200, 20, player.health, player.shield)
        draw_health_bar(150, 25, 200, 20, player.health, player.shield)
        
        # Draw weapon indicator
        draw_weapon_indicator(20, HEIGHT - 120, player.weapon)
        
        # Draw UI panel
        draw_ui_panel()
        
        # 应用屏幕特效
        apply_screen_effects()
        
        # 绘制BOSS警告
        if boss_warning_timer > 0:
            draw_boss_warning()
        
        # Apply screen shake effect
        if shake_offset != (0, 0):
            screen_scroll = pygame.Surface((WIDTH, HEIGHT))
            screen_scroll.blit(screen, (0, 0))
            screen.blit(screen_scroll, shake_offset)
        
        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()


