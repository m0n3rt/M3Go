import pygame
import sys
import os
import random
from pygame import gfxdraw
from game_utils import set_input_method_to_english, GameData

# 初始化pygame
pygame.init()

# 游戏窗口设置
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Warrior Rimer")

# 颜色定义
BACKGROUND = (20, 20, 35)
TEXT_COLOR = (220, 220, 220)
BUTTON_COLOR = (0, 150, 200)
BUTTON_HOVER_COLOR = (0, 200, 255)
BUTTON_TEXT_COLOR = (255, 255, 255)
COUNTDOWN_COLOR = (255, 215, 0)
HISTORY_BG = (30, 30, 50, 200)
HISTORY_HEADER = (70, 70, 100)
HISTORY_ROW_EVEN = (40, 40, 60, 180)
HISTORY_ROW_ODD = (50, 50, 70, 180)

# 字体
title_font = pygame.font.SysFont(None, 72)
button_font = pygame.font.SysFont(None, 48)
countdown_font = pygame.font.SysFont(None, 120)
history_font = pygame.font.SysFont(None, 28)
history_header_font = pygame.font.SysFont(None, 32)

try:
    # 获取当前脚本所在目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 加载玩家受击音效
    button_click_sound = pygame.mixer.Sound(os.path.join(current_dir, "music", "player_hit.wav"))
    button_click_sound.set_volume(0.3)  # 降低音量避免过于刺耳
except Exception as e:
    print(f"无法加载按钮音效: {str(e)}")
    # 创建空音效对象作为后备
    class DummySound:
        def play(self): pass
    button_click_sound = DummySound()

# 绘制背景网格
def draw_background():
    screen.fill(BACKGROUND)
    for i in range(0, WIDTH, 30):
        pygame.draw.line(screen, (30, 30, 45), (i, 0), (i, HEIGHT), 1)
    for i in range(0, HEIGHT, 30):
        pygame.draw.line(screen, (30, 30, 45), (0, i), (WIDTH, i), 1)

# 在start_menu.py中修改

def draw_background():
    # 添加星空动态背景
    screen.fill(BACKGROUND)
    # 绘制动态星空
    for i in range(100):
        x = (pygame.time.get_ticks() // 30 + i * 100) % WIDTH
        y = (i * 20 + pygame.time.get_ticks() // 50) % HEIGHT
        size = random.randint(1, 3)
        alpha = random.randint(100, 200)
        pygame.draw.circle(screen, (200, 200, 255, alpha), (x, y), size)
    
    # 添加标题发光效果
    title_text = title_font.render("Warrior Rimer", True, (0, 200, 255))
    text_rect = title_text.get_rect(center=(WIDTH//2, HEIGHT//4 + 25))
    
    # 添加发光效果
    for i in range(10, 0, -1):
        glow_color = (0, 100, 200, 10 * i)
        glow_surf = pygame.Surface((text_rect.width + i*10, text_rect.height + i*10), pygame.SRCALPHA)
        pygame.draw.rect(glow_surf, glow_color, glow_surf.get_rect(), border_radius=15)
        screen.blit(glow_surf, (text_rect.centerx - glow_surf.get_width()//2, 
                               text_rect.centery - glow_surf.get_height()//2))
    
    screen.blit(title_text, text_rect)

def draw_glass_button(rect, text, hover=False):
    # 创建玻璃态按钮
    button_surf = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    
    # 基础玻璃效果
    pygame.draw.rect(button_surf, (255, 255, 255, 50), button_surf.get_rect(), border_radius=10)
    pygame.draw.rect(button_surf, (255, 255, 255, 150), button_surf.get_rect(), 3, border_radius=10)
    
    # 悬停效果
    if hover:
        # 添加发光边框
        pygame.draw.rect(button_surf, (0, 200, 255, 100), button_surf.get_rect(), 6, border_radius=10)
        # 添加内部光效
        inner_rect = pygame.Rect(5, 5, rect.width-10, rect.height-10)
        pygame.draw.rect(button_surf, (0, 200, 255, 30), inner_rect, border_radius=8)
    
    # 添加文字
    text_surf = button_font.render(text, True, BUTTON_TEXT_COLOR)
    text_rect = text_surf.get_rect(center=(rect.width//2, rect.height//2))
    button_surf.blit(text_surf, text_rect)
    
    # 添加高光
    highlight = pygame.Surface((rect.width, 15), pygame.SRCALPHA)
    highlight.fill((255, 255, 255, 80))
    button_surf.blit(highlight, (0, 5))
    
    screen.blit(button_surf, rect.topleft)

# 绘制历史记录面板
def show_history_panel():
    history_data = GameData.get_history()
    back_button = pygame.Rect(WIDTH//2 - 100, HEIGHT - 80, 200, 50)
    
    # 计算历史记录面板的位置和大小
    panel_width = 700
    panel_height = 400
    panel_x = (WIDTH - panel_width) // 2
    panel_y = 100
    
    while True:
        mouse_pos = pygame.mouse.get_pos()
        back_hover = back_button.collidepoint(mouse_pos)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if back_button.collidepoint(mouse_pos):
                    button_click_sound.play()
                    return
        
        draw_background()
        
        # 绘制历史记录面板背景
        history_surface = pygame.Surface((panel_width, panel_height), pygame.SRCALPHA)
        history_surface.fill(HISTORY_BG)
        screen.blit(history_surface, (panel_x, panel_y))
        
        # 绘制标题
        title_text = title_font.render("Game History", True, (255, 215, 0))
        screen.blit(title_text, (WIDTH//2 - title_text.get_width()//2, 30))
        
        # 绘制表头
        header_surface = pygame.Surface((panel_width - 20, 40), pygame.SRCALPHA)
        header_surface.fill(HISTORY_HEADER)
        screen.blit(header_surface, (panel_x + 10, panel_y + 10))
        
        headers = ["Date", "Time", "Score"]
        header_widths = [200, 200, 200]
        header_x = panel_x + 50
        
        for i, header in enumerate(headers):
            header_text = history_header_font.render(header, True, (220, 220, 220))
            screen.blit(header_text, (header_x, panel_y + 20))
            header_x += header_widths[i]
        
        # 绘制历史记录
        if not history_data:
            no_data_text = history_font.render("No game records yet. Play a game to create records!", True, (200, 150, 150))
            screen.blit(no_data_text, (panel_x + 100, panel_y + 150))
        else:
            for i, record in enumerate(reversed(history_data)):
                row_y = panel_y + 60 + i * 40
                
                # 交替行颜色
                if i % 2 == 0:
                    row_color = HISTORY_ROW_EVEN
                else:
                    row_color = HISTORY_ROW_ODD
                
                row_surface = pygame.Surface((panel_width - 20, 35), pygame.SRCALPHA)
                row_surface.fill(row_color)
                screen.blit(row_surface, (panel_x + 10, row_y))
                
                # 绘制日期
                date_text = history_font.render(record["date"], True, TEXT_COLOR)
                screen.blit(date_text, (panel_x + 60, row_y + 10))
                
                # 绘制时间
                time_text = history_font.render(record["time"], True, TEXT_COLOR)
                screen.blit(time_text, (panel_x + 260, row_y + 10))
                
                # 绘制分数
                score_text = history_font.render(str(record["score"]), True, (255, 215, 0))
                screen.blit(score_text, (panel_x + 460, row_y + 10))
                
                # 只显示10条记录
                if i >= 7:
                    break
        
        # 绘制返回按钮
        button_color = BUTTON_HOVER_COLOR if back_hover else BUTTON_COLOR
        pygame.draw.rect(screen, button_color, back_button, border_radius=10)
        pygame.draw.rect(screen, (0, 100, 150), back_button, 3, border_radius=10)
        
        back_text = button_font.render("BACK", True, BUTTON_TEXT_COLOR)
        screen.blit(back_text, (WIDTH//2 - back_text.get_width()//2, 
                                HEIGHT - 80 + back_text.get_height()//2))
        
        pygame.display.flip()
        pygame.time.delay(30)

# 主菜单
def show_main_menu():
    start_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2, 200, 60)
    history_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 80, 200, 60)
    continue_button = pygame.Rect(WIDTH//2 - 100, HEIGHT//2 + 160, 200, 60)
    
    button_hover = [False, False, False]  # [start, history, continue]
    
    # 获取最高分
    high_score = GameData.get_high_score()
    
    # 检查是否有保存的游戏
    has_saved_game = GameData.has_saved_game()
    
    while True:
        mouse_pos = pygame.mouse.get_pos()
        button_hover[0] = start_button.collidepoint(mouse_pos)
        button_hover[1] = history_button.collidepoint(mouse_pos)
        button_hover[2] = continue_button.collidepoint(mouse_pos) and has_saved_game
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.collidepoint(mouse_pos):
                    button_click_sound.play()  
                    return show_countdown()
                if history_button.collidepoint(mouse_pos):
                    button_click_sound.play()  
                    show_history_panel()
                if continue_button.collidepoint(mouse_pos) and has_saved_game:
                    button_click_sound.play()
                    # 加载保存的游戏
                    return True

        draw_background()
        
        # 绘制标题
        title_text = title_font.render("Warrior Rimer", True, TEXT_COLOR)
        screen.blit(title_text, (WIDTH//2 - title_text.get_width()//2, HEIGHT//4))
        
        # 绘制最高分
        high_score_text = button_font.render(f"Highest Score: {high_score}", True, (255, 215, 0))
        screen.blit(high_score_text, (WIDTH//2 - high_score_text.get_width()//2, HEIGHT//4 + 70))
        
        # 绘制按钮
        start_color = BUTTON_HOVER_COLOR if button_hover[0] else BUTTON_COLOR
        pygame.draw.rect(screen, start_color, start_button, border_radius=10)
        pygame.draw.rect(screen, (0, 100, 150), start_button, 3, border_radius=10)
        
        start_text = button_font.render("START", True, BUTTON_TEXT_COLOR)
        screen.blit(start_text, (WIDTH//2 - start_text.get_width()//2, 
                                HEIGHT//2 + start_text.get_height()//2))
        
        # 绘制历史记录按钮
        history_color = BUTTON_HOVER_COLOR if button_hover[1] else BUTTON_COLOR
        pygame.draw.rect(screen, history_color, history_button, border_radius=10)
        pygame.draw.rect(screen, (0, 100, 150), history_button, 3, border_radius=10)
        
        history_text = button_font.render("HISTORY", True, BUTTON_TEXT_COLOR)
        screen.blit(history_text, (WIDTH//2 - history_text.get_width()//2, 
                                 HEIGHT//2 + 80 + history_text.get_height()//2))
        
        # 绘制继续游戏按钮（如果有保存的游戏）
        if has_saved_game:
            continue_color = BUTTON_HOVER_COLOR if button_hover[2] else (200, 150, 50)
            pygame.draw.rect(screen, continue_color, continue_button, border_radius=10)
            pygame.draw.rect(screen, (220, 180, 70), continue_button, 3, border_radius=10)
            
            continue_text = button_font.render("CONTINUE", True, BUTTON_TEXT_COLOR)
            screen.blit(continue_text, (WIDTH//2 - continue_text.get_width()//2, 
                                     HEIGHT//2 + 160 + continue_text.get_height()//2))
        else:
            # 如果无保存的游戏，显示灰色按钮
            pygame.draw.rect(screen, (100, 100, 100), continue_button, border_radius=10)
            pygame.draw.rect(screen, (130, 130, 130), continue_button, 3, border_radius=10)
            
            continue_text = button_font.render("CONTINUE", True, (180, 180, 180))
            screen.blit(continue_text, (WIDTH//2 - continue_text.get_width()//2, 
                                     HEIGHT//2 + 160 + continue_text.get_height()//2))
        
        # 绘制说明
        controls_font = pygame.font.SysFont(None, 28)
        controls_text = [
            "Controls:",
            "WASD - Move",
            "SPACE - Shoot",
            "M - Pause Game",
            "1,2,3 - Switch Weapons",
            "F - Activate Attack Boost"
        ]
        
        for i, text in enumerate(controls_text):
            text_surface = controls_font.render(text, True, (180, 180, 200))
            screen.blit(text_surface, (WIDTH//2 + 150, 
                                     HEIGHT - 150 + i * 30 - 30))
        
        pygame.display.flip()
        pygame.time.delay(30)

# 倒计时
def show_countdown():
    countdown_values = [3, 2, 1]
    
    for count in countdown_values:
        for _ in range(60):  # 每秒钟60帧
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            
            draw_background()
            
            # 绘制倒计时数字
            count_text = countdown_font.render(str(count), True, COUNTDOWN_COLOR)
            text_rect = count_text.get_rect(center=(WIDTH//2, HEIGHT//2))
            
            # 添加发光效果
            glow_surface = pygame.Surface((text_rect.width + 40, text_rect.height + 40), pygame.SRCALPHA)
            for i in range(10, 0, -1):
                alpha = 100 - i * 10
                glow_color = (255, 215, 0, alpha)
                pygame.draw.circle(glow_surface, glow_color, 
                                  (glow_surface.get_width()//2, glow_surface.get_height()//2), 
                                  i * 3)
            
            screen.blit(glow_surface, (text_rect.centerx - glow_surface.get_width()//2, 
                                      text_rect.centery - glow_surface.get_height()//2))
            
            screen.blit(count_text, text_rect)
            
            pygame.display.flip()
            pygame.time.delay(16)  # 约60FPS
    
    return True

# 主函数
def main():
    # 确保输入法是英文
    set_input_method_to_english()
    
    # 主循环，允许从游戏返回后重新显示菜单
    while True:
        # 显示主菜单
        continue_saved = show_main_menu()
        
        # 倒计时结束后启动游戏
        import main_game
        # 如果是继续游戏，加载保存的状态
        main_game.main(load_saved_state=continue_saved)

if __name__ == "__main__":
    main()


