# Warrior Rimer 游戏

## 游戏介绍
一个基于Python和Pygame的射击游戏。

## 安装方法
1. 确保安装了Python 3.6+
2. 安装依赖: `pip install -r requirements.txt`
3. 运行游戏: `python start_game.py`

## 游戏控制
- WASD: 移动
- 空格: 射击
- 1,2,3: 切换武器
- F: 激活攻击加速
- M: 暂停游戏